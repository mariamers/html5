export const Users = [
    {
      "id": 1,
      "first_name": "110621",
      "last_name": "McClune",
      "email": "0",
      "gender": "60",
      "dep": "CCHLA",
    },
    {
      "id": 2,
      "first_name": "110621",
      "last_name": "Ingleston",
      "email": "0",
      "gender": "30",
      "dep": "CCHLA",
    },
    {
      "id": 3,
      "first_name": "110621",
      "last_name": "Bergstram",
      "email": "0",
      "gender": "30",
      "dep": "CCHLA",
    },
    {
      "id": 4,
      "first_name": "110621",
      "last_name": "Knighton",
      "email": "0",
      "gender": "60",
      "dep": "CCHLA",
    },
    {
      "id": 5,
      "first_name": "110621",
      "last_name": "Naulty",
      "email": "0",
      "gender": "30"
   , 
   "dep": "CCHLA", 
  },
    {
      "id": 6,
      "first_name": "110621",
      "last_name": "Cockayme",
      "email": "0",
      "gender": "60"
   ,
   "dep": "CCHLA", },
    {
      "id": 7,
      "first_name": "110621",
      "last_name": "Sharvill",
      "email": "0",
      "gender": "30"
   ,
   "dep": "CCHLA", },
    {
      "id": 8,
      "first_name": "110621",
      "last_name": "Ricket",
      "email": "0",
      "gender": "60"
   ,
   "dep": "CCHLA", }
    ]
  